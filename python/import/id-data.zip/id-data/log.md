## 17-apr-2022
Test a `file.py` to use `id_data` as a package

```
python -m tests.testfile
```

where it should be placed in `tests` folder.
