level = 3
name = 'Cangkuang'
capital = 'Ciluncat'
area = 24.61
