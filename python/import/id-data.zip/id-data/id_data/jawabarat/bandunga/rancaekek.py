level = 3
name = 'Rancaekek'
capital = 'Rancaekek Wetan'
area = 45.25
