level = 3
name = 'Majalaya'
capital = 'Majasetra'
area = 25.36
