level = 3
name = 'Solokanjeruk'
capital = 'Solokanjeruk'
area = 24.01
