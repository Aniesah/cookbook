level = 3
name = 'Nagreg'
capital = 'Ganjarsabar'
area = 49.3
