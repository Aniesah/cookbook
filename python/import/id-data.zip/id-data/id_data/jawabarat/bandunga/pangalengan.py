level = 3
name = 'Pangalengan'
capital = 'Pangalengan'
area = 195.41
