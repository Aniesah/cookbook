level = 3
name = 'Margaasih'
capital = 'Margaasih'
area = 18.35
