level = 3
name = 'Katapang'
capital = 'Sangkanhurip'
area = 15.72
