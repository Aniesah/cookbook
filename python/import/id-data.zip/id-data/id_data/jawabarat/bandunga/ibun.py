level = 3
name = 'Ibun'
capital = 'Ibun'
area = 54.57
