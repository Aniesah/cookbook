level = 3
name = 'Paseh'
capital = 'Tangsimekar'
area = 51.03
