level = 3
name = 'Margahayu'
capital = 'Sukamenak'
area = 10.54
