level = 3
name = 'Arjasari'
capital = 'Patrolsari'
area = 64.98
