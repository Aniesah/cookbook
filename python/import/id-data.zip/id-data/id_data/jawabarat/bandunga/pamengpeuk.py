level = 3
name = 'Pamengpeuk'
capital = 'Sukasari'
area = 14.62

