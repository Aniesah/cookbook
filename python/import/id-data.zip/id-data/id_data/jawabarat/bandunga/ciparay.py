level = 3
name = 'Ciparay'
capital = 'Pakutandang'
area = 46.18
