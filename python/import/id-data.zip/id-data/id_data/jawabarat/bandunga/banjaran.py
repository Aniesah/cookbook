level = 3
name = 'Banjaran'
capital = 'Banjaran'
area = 42.92
