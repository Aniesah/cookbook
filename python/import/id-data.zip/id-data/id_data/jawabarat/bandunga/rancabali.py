level = 3
name = 'Rancabali'
capital = 'Patengan'
area = 148.37
