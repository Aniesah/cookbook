level = 3
name = 'Kutawaringin'
capital = 'Jatisari'
area = 47.3
