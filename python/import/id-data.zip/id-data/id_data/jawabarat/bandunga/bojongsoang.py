level = 3
name = 'Bojongsoang'
capital = 'Bojongsoang'
area = 27.81
