level = 3
name = 'Soreang'
capital = 'Soreang'
area = 25.51
