level = 3
name = 'Kertasari'
capital = 'Cibeureum'
area = 152.07
