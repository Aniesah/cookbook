level = 3
name = 'Cikancung'
capital = 'Cikancung'
area = 40.14
