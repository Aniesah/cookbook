level = 3
name = 'Ciwidey'
capital = 'Lebakmuncang'
area = 48.47
