level = 3
name = 'Cicalengka'
capital = 'Cicalengka Kulon'
area = 35.99
