level = 3
name = 'Ngamprah'
capital = 'Ngamprah'
area = 36.01
