level = 3
name = 'Lembang'
capital = 'Lembang'
area = 95.56
