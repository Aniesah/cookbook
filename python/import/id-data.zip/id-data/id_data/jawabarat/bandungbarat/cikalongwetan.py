level = 3
name = 'Cikalong Wetan'
capital = 'Cikalong Wetan'
area = 112.93
