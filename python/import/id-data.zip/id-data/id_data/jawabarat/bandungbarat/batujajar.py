level = 3
name = 'Batujajar'
capital = 'Batujajar'
area = 32.04
