level = 3
name = 'Padalarang'
capital = 'Padalarang'
area = 51.4
