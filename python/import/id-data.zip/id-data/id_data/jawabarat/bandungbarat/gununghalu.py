level = 3
name = 'Gununghalu'
capital = 'Gununghalu'
area = 160.64
