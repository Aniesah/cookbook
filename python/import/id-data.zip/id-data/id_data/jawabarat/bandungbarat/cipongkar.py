level = 3
name = 'Cipongkor'
capital = 'Cipongkor'
area = 79.96
