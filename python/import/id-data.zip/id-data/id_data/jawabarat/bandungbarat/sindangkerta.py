level = 3
name = 'Sindangkerta'
capital = 'Sindangkerta'
area = 120.47
