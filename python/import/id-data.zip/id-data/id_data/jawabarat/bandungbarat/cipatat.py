level = 3
name = 'Cipatat'
capital = 'Cipatat'
area = 126.05
