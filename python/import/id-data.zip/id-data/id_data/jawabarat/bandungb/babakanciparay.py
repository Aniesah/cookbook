level = 3
name = 'Babakan Ciparay'
capital = 'Babakan Ciparay'
area = 7.45
