level = 3
name = 'Bojongloa Kaler'
capital = 'Suka Asih'
area = 3.03
