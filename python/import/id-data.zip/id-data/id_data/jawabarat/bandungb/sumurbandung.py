level = 3
name = 'Sumur Bandung'
capital = 'Merdeka'
area = 3.40
