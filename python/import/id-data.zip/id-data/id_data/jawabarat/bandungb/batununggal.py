level = 3
name = 'Batununggal'
capital = 'Gumuruh'
area = 5.03
