level = 3
name = 'Sukasari'
capital = 'Sukarasa'
area = 6.27
