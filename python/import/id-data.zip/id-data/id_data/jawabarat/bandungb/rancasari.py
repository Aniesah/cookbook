level = 3
name = 'Rancasari'
capital = 'Cipamokolan'
area = 7.33
