level = 3
name = 'Bojongloa Kidul'
capital = 'Situsaeur'
area = 6.26
