level = 3
name = 'Regol'
capital = 'Ciseureuh'
area = 4.30
