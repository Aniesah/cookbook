level = 3
name = 'Astanaanyar'
capital = 'Panjunan'
area = 2.89
