level = 3
name = 'Cinambo'
capital = 'Pakemitan'
area = 3.68
