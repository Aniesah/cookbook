level = 3
name = 'Bandung Kidul'
capital = 'Mengger'
area = 6.06
