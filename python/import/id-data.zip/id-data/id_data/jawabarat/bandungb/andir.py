level = 3
name = 'Andir'
capital = 'Garuda'
area = 3.71
