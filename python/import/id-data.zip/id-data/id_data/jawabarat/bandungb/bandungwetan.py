level = 3
name = 'Bandung Wetan'
capital = 'Tamansari'
area = 3.39
