level = 3
name = 'Cibiru'
capital = 'Cipadung'
area = 6.32
