level = 3
name = 'Mandalajati'
capital = 'Karang Pamulang'
area = 6.67
