level = 3
name = 'Cibeunying Kaler'
capital = 'Cigadung'
area = 4.50
