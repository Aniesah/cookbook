level = 3
name = 'Cibeunying Kidul'
capital = 'Cikutra'
area = 5.25
