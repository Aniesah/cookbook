level = 3
name = 'Bandung Kulon'
capital = 'Caringin'
area = 6.46
