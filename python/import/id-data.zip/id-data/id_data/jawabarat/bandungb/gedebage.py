level = 3
name = 'Gedebage'
capital = 'Rancabolang'
area = 9.58
