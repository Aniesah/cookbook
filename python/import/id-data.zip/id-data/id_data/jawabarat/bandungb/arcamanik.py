level = 3
name = 'Arcamanik'
capital = 'Cisaranten Kulon'
area = 5.87
