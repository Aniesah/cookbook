level = 3
name = 'Kiaracondong'
capital = 'Babakan Sari'
area = 6.12
