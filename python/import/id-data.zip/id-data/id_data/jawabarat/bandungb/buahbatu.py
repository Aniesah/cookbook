level = 3
name = 'Buah Batu'
capital = 'Margasari'
area = 7.93
