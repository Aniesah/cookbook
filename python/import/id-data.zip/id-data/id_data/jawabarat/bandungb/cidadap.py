level = 3
name = 'Cidadap'
capital = 'Hegarmanah'
area = 6.11
