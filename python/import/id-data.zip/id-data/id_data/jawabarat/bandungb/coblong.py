level = 3
name = 'Coblong'
capital = 'Dago'
area = 7.35
