level = 3
name = 'Lengkong'
capital = 'Malabar'
area = 5.90
