level = 3
name = 'Sukajadi'
capital = 'Sukagalih'
area = 4.30
