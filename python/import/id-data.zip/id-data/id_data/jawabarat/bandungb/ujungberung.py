level = 3
name = 'Ujungberung'
capital = 'Cigending'
area = 6.40
