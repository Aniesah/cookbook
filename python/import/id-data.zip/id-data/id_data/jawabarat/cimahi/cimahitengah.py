level = 3
name = 'Cimahi Tengah'
capital = 'Cimahi'
area = 10.11

population = {
  '2021': 161758000,
}
