level = 3
name = 'Cimahi Utara'
capital = 'Cibabat'
area = 13.32

population = {
  '2021': 165652000,
}
