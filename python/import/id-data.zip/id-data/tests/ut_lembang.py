import id_data.jawabarat.bandungbarat.lembang as lem

print(lem.name, lem.level, lem.area)
